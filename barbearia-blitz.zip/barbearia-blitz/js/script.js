(function () {
  'use strict';
  var top = document.querySelector('.top');
  var burger = document.querySelector('.burger');
  var menu = document.getElementById('menu');

  // Links do WhatsApp com mensagem pronta
  document.querySelectorAll('[data-wa]').forEach(function (a) {
    a.href = 'https://wa.me/5594981551611?text=' + encodeURIComponent(a.dataset.wa);
  });

  // Menu hambúrguer
  function setMenu(open) {
    menu.classList.toggle('open', open);
    burger.setAttribute('aria-expanded', open);
    burger.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
  }
  burger.addEventListener('click', function () { setMenu(!menu.classList.contains('open')); });
  menu.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });

  // Cabeçalho muda ao rolar
  function onScroll() { top.classList.toggle('scrolled', window.scrollY > 40); }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // Galeria: ampliar foto ao clicar (só funciona onde houver <img>)
  var lb = document.getElementById('lb');
  var big = lb.querySelector('img');
  document.querySelector('.gal').addEventListener('click', function (e) {
    var img = e.target.closest('img');
    if (!img) return;
    big.src = img.src;
    big.alt = img.alt;
    lb.showModal();
  });
  lb.addEventListener('click', function () { lb.close(); });

  // Ano automático
  document.getElementById('ano').textContent = new Date().getFullYear();
})();
